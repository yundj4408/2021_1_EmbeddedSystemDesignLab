int main(void) {

    unsigned int on = 0;

    while (1);
}

