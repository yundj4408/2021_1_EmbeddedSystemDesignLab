
//#define P0HW_ADDR 0x40000000
//#define POHW (*(unsigned char*)POHW_ADDR) 
int sum(int a, int b);
int main(){
    int P0;    //char 선언
    int P1;
   
    // clear
    P0 = 0x10;
    P1 = 0x20;
    
    sum(P0, P1);
    //POHW_ADDR = 0x4F;
    
	while(1);
}

int sum(int a, int b) {
    return a+b;
}
