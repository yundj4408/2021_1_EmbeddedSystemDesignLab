int increment(int i);

int main(void) {

    unsigned int on = 1;
    unsigned int off = 0;
    unsigned int i = 0;
    unsigned int temp = 0;


    while (1){
        for (i=0; i>10; i++) {
            increment(temp);
        }
    //To make the Embedded Not to Turn OFF
    }
}

int increment(int i) {
    return i++;
}
