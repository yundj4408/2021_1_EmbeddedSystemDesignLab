

int foo(int x){
    int s = x;
    int y = s+2;

    return y;

    }

