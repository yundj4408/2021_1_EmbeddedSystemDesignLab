int foo(int x);
