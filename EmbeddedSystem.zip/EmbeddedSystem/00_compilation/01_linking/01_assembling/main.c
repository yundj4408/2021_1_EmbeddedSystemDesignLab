#include"foo.h"
#include<stdio.h>

int main(){
    int y = foo(2);
    printf("y is %d\n",y);
    
}
