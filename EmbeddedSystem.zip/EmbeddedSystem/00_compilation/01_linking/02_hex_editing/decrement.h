int decrement(int i);
