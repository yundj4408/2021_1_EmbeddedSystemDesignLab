int decrement(int i){
    return i-1;
}
