int increment(int i);
