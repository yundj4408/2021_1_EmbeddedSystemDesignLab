
int increment(int i){
    return i+1;
}
