#include"increment.h"
#include"decrement.h"
#include<stdio.h>

int main(){
    int y = increment(10);
    printf("y is %d\n",y);
    
}
